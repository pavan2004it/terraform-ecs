import boto3
import botocore
import click

ec2 = boto3.resource('ec2')
elbList = boto3.client('elbv2')
def filter_instances(project):
    instances = []

    if project:
        filters = [{'Name':'tag:Project', 'Values':[project]}]
        instances = ec2.instances.filter(Filters=filters)
    else:
        instances = ec2.instances.all()

    return instances

def has_pending_snapshot(volume):
    snapshots = list(volume.snapshots.all())
    return snapshots and snapshots[0].state == 'pending'


def tar_instances(project):
    instances = []
    if project:
        filters = [{'Name':'tag:Project', 'Values':[project]}]
        instances = ec2.instances.filter(Filters=filters)
    else:
        instances = ec2.instances.all()

    return instances


def lst_targets(project):
     loadbalancers = elbList.describe_target_health(TargetGroupArn='arn:aws:elasticloadbalancing:eu-west-1:672985825598:targetgroup/test/4ae1eee6118aae2e')
     "list the targets"
     for target in loadbalancers['TargetHealthDescriptions']:
         target_id = target['Target']['Id']

     return target_id



@click.group()
def cli():
    """awssnapelb manages snapshots"""
@cli.group('lb')
def lb():
    """Commands for load balancers"""
@lb.command('listlbs')
@click.option('--project', default=None,help="only the elb's for the project (tag Project:<name>)")
def list_loadbalancers(project):
    loadbalancers = elbList.describe_load_balancers()
    "List the lb's"
    for elb in loadbalancers['LoadBalancers']:
        print('ELB Name : ' + elb['LoadBalancerName'])
    return

@lb.command('listtargetgroups')
@click.option('--project', default=None,help="only the targets for the project (tag Project:<name>)")
def list_targetgroups(project):
    loadbalancers = elbList.describe_target_groups()
    "List Targetgroups in the ELB"
    for elb in loadbalancers['TargetGroups']:
        print('ELB Target group Name : ' + elb['TargetGroupName'])
    return




@lb.command('removetargets')
@click.option('--project', default=None,help="only the targets for the project (tag Project:<name>)")

def rm_targets(project):
     target_id = lst_targets(project)
     Targets = []
     Target = {}
     Target['Id'] = target_id
     Targets.append(Target)
     lbs = elbList.deregister_targets(TargetGroupArn='arn:aws:elasticloadbalancing:eu-west-1:672985825598:targetgroup/test/4ae1eee6118aae2e',Targets=Targets)
     print(lbs)


@lb.command('addtargets')
@click.option('--project', default=None,help="only the targets for the project (tag Project:<name>)")

def add_targets(project):
     target_id = tar_instances(project)
     for i in target_id:
        Targets = []
        Target = {}
        Target['Id'] = i.id
        Target['Port'] = 80
        Targets.append(Target)
     print(Targets)
     lbs = elbList.register_targets(TargetGroupArn='arn:aws:elasticloadbalancing:eu-west-1:672985825598:targetgroup/test/4ae1eee6118aae2e',Targets=Targets)
     print(lbs)




@cli.group('snapshots')
def snapshots():
    """Commands for snapshots"""

@snapshots.command('list')
@click.option('--project', default=None,
    help="Only snapshots for project (tag Project:<name>)")
@click.option('--all', 'list_all', default=False, is_flag=True,
    help="List all snapshots for each volume, not just the most recent")
def list_snapshots(project, list_all):
    "List EC2 snapshots"

    instances = filter_instances(project)

    for i in instances:
        for v in i.volumes.all():
            for s in v.snapshots.all():
                print(", ".join((
                    s.id,
                    v.id,
                    i.id,
                    s.state,
                    s.progress,
                    s.start_time.strftime("%c")
                )))

                if s.state == 'completed' and not list_all: break

    return

@cli.group('volumes')
def volumes():
    """Commands for volumes"""

@volumes.command('list')
@click.option('--project', default=None,
    help="Only volumes for project (tag Project:<name>)")
def list_volumes(project):
    "List EC2 volumes"

    instances = filter_instances(project)

    for i in instances:
        for v in i.volumes.all():
            print(", ".join((
                v.id,
                i.id,
                v.state,
                str(v.size) + "GiB",
                v.encrypted and "Encrypted" or "Not Encrypted"
            )))

    return

@cli.group('instances')
def instances():
    """Commands for instances"""

@instances.command('snapshot',
    help="Create snapshots of all volumes")
@click.option('--project', default=None,
    help="Only instances for project (tag Project:<name>)")
def create_snapshots(project):
    "Create snapshots for EC2 instances"

    instances = filter_instances(project)

    for i in instances:
        print("Stopping {0}...".format(i.id))

        i.stop()
        i.wait_until_stopped()

        for v in i.volumes.all():
            if has_pending_snapshot(v):
                print("  Skipping {0}, snapshot already in progress".format(v.id))
                continue

            print("  Creating snapshot of {0}".format(v.id))
            v.create_snapshot(Description="Created by SnapshotAlyzer 30000")

        print("Starting {0}...".format(i.id))

        i.start()
        i.wait_until_running()

    print("Job's done!")

    return

@instances.command('list')
@click.option('--project', default=None,
    help="Only instances for project (tag Project:<name>)")
def list_instances(project):
    "List EC2 instances"

    instances = filter_instances(project)

    for i in instances:
        tags = { t['Key']: t['Value'] for t in i.tags or [] }
        print(', '.join((
            i.id,
            i.instance_type,
            i.placement['AvailabilityZone'],
            i.state['Name'],
            i.public_dns_name,
            tags.get('Project', '<no project>')
            )))

    return

@instances.command('stop')
@click.option('--project', default=None,
  help='Only instances for project')
def stop_instances(project):
    "Stop EC2 instances"

    instances = filter_instances(project)

    for i in instances:
        print("Stopping {0}...".format(i.id))
        try:
            i.stop()
        except botocore.exceptions.ClientError as e:
            print(" Could not stop {0}. ".format(i.id) + str(e))
            continue

    return

@instances.command('start')
@click.option('--project', default=None,
  help='Only instances for project')
def start_instances(project):
    "Start EC2 instances"

    instances = filter_instances(project)

    for i in instances:
        print("Starting {0}...".format(i.id))
        try:
            i.start()
        except botocore.exceptions.ClientError as e:
            print(" Could not start {0}. ".format(i.id) + str(e))
            continue

    return

if __name__ == '__main__':
    cli()

